import { ScrollView, Text, View, Pressable, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useGame } from "@/lib/game-context";
import { useEffect, useState } from "react";
import * as Haptics from "expo-haptics";

const RETIREMENT_GOAL = 1000;

export default function LeaderboardScreen() {
  const { state, incrementCommunity } = useGame();
  const [showCelebration, setShowCelebration] = useState(false);

  const progressPercent = Math.min(100, (state.communityMembers / RETIREMENT_GOAL) * 100);
  const isGoalReached = state.communityMembers >= RETIREMENT_GOAL;

  useEffect(() => {
    if (isGoalReached && !showCelebration) {
      setShowCelebration(true);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  }, [isGoalReached]);

  const handleAddMember = () => {
    incrementCommunity();
    Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-8 gap-4">
          <Text className="text-2xl font-bold text-background">Retirement Goal</Text>
          <Text className="text-sm text-background opacity-80">
            Reach 1,000 community members to retire!
          </Text>
        </View>

        {/* Main Content */}
        <View className="px-6 py-8 gap-6">
          {/* Goal Card */}
          <View className="bg-surface rounded-lg p-6 border border-border gap-4">
            <View className="gap-2">
              <View className="flex-row justify-between items-center">
                <Text className="text-sm font-semibold text-foreground">Community Members</Text>
                <Text className="text-sm font-bold text-primary">
                  {state.communityMembers} / {RETIREMENT_GOAL}
                </Text>
              </View>

              {/* Progress Bar */}
              <View className="h-3 bg-border rounded-full overflow-hidden">
                <View
                  className="h-full bg-primary rounded-full"
                  style={{ width: `${progressPercent}%` }}
                />
              </View>

              <Text className="text-xs text-muted">
                {Math.floor(progressPercent)}% to retirement
              </Text>
            </View>

            {/* Milestone Messages */}
            {progressPercent >= 50 && progressPercent < 100 && (
              <View className="bg-warning bg-opacity-10 rounded p-3 gap-1 border border-warning border-opacity-30">
                <Text className="text-sm font-semibold text-warning">🎯 Halfway there!</Text>
                <Text className="text-xs text-warning opacity-80">
                  {RETIREMENT_GOAL - state.communityMembers} more members needed
                </Text>
              </View>
            )}

            {isGoalReached && (
              <View className="bg-success bg-opacity-10 rounded p-3 gap-1 border border-success border-opacity-30">
                <Text className="text-sm font-bold text-success">🎉 Goal Reached!</Text>
                <Text className="text-xs text-success opacity-80">
                  Time to retire and enjoy the fruits of your labor!
                </Text>
              </View>
            )}
          </View>

          {/* Celebration Section */}
          {isGoalReached && (
            <View className="bg-primary bg-opacity-10 rounded-lg p-6 border border-primary border-opacity-30 gap-4">
              <View className="items-center gap-2">
                <Text className="text-5xl">🏖️</Text>
                <Text className="text-2xl font-bold text-foreground text-center">Congratulations!</Text>
                <Text className="text-sm text-muted text-center">
                  You've successfully built Biron into a thriving marketplace. Time to retire and enjoy your success!
                </Text>
              </View>
            </View>
          )}

          {/* Test Button */}
          <Pressable
            onPress={handleAddMember}
            className="bg-primary rounded-lg py-3 active:opacity-80"
          >
            <Text className="text-background font-bold text-center">+ Add Community Member</Text>
          </Pressable>

          {/* Stats */}
          <View className="bg-surface rounded-lg p-4 border border-border gap-3">
            <Text className="text-sm font-semibold text-foreground mb-2">Community Stats</Text>
            <View className="gap-2">
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Total Members</Text>
                <Text className="text-sm font-bold text-foreground">{state.communityMembers}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Your Level</Text>
                <Text className="text-sm font-bold text-foreground">{state.level}</Text>
              </View>
              <View className="flex-row justify-between">
                <Text className="text-sm text-muted">Your Items</Text>
                <Text className="text-sm font-bold text-foreground">{state.inventory.length}</Text>
              </View>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

import { ScrollView, Text, View, Pressable, Alert, Switch } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useGame } from "@/lib/game-context";
import { useColorScheme } from "@/hooks/use-color-scheme";
import { useColors } from "@/hooks/use-colors";
import * as Haptics from "expo-haptics";

export default function SettingsScreen() {
  const { state, resetGame } = useGame();
  const colorScheme = useColorScheme();
  const colors = useColors();

  const handleResetGame = () => {
    Alert.alert("Reset Game", "Are you sure you want to reset all progress? This cannot be undone.", [
      { text: "Cancel", onPress: () => {}, style: "cancel" },
      {
        text: "Reset",
        onPress: () => {
          resetGame();
          Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        },
        style: "destructive",
      },
    ]);
  };

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-8 gap-2">
          <Text className="text-2xl font-bold text-background">Settings</Text>
          <Text className="text-sm text-background opacity-80">Customize your experience</Text>
        </View>

        {/* Settings Sections */}
        <View className="px-6 py-6 gap-6">
          {/* App Info */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">App Information</Text>
            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">App Name</Text>
                <Text className="text-sm font-semibold text-foreground">Biron</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Version</Text>
                <Text className="text-sm font-semibold text-foreground">1.0.0</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Theme</Text>
                <Text className="text-sm font-semibold text-foreground capitalize">{colorScheme || "auto"}</Text>
              </View>
            </View>
          </View>

          {/* Game Stats */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">Your Progress</Text>
            <View className="bg-surface rounded-lg p-4 border border-border gap-3">
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Current Level</Text>
                <Text className="text-sm font-bold text-primary">{state.level}</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Total XP</Text>
                <Text className="text-sm font-bold text-success">{state.totalXp}</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Items Collected</Text>
                <Text className="text-sm font-bold text-foreground">{state.inventory.length}</Text>
              </View>
              <View className="h-px bg-border" />
              <View className="flex-row justify-between items-center">
                <Text className="text-sm text-muted">Community Members</Text>
                <Text className="text-sm font-bold text-foreground">{state.communityMembers}</Text>
              </View>
            </View>
          </View>

          {/* Danger Zone */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">Danger Zone</Text>
            <Pressable
              onPress={handleResetGame}
              className="bg-error bg-opacity-10 rounded-lg p-4 border border-error border-opacity-30 active:opacity-80"
            >
              <Text className="text-sm font-semibold text-error text-center">Reset All Progress</Text>
            </Pressable>
          </View>

          {/* About */}
          <View className="gap-3">
            <Text className="text-sm font-semibold text-foreground">About</Text>
            <View className="bg-surface rounded-lg p-4 border border-border gap-2">
              <Text className="text-sm text-foreground font-semibold">Biron Marketplace</Text>
              <Text className="text-xs text-muted leading-relaxed">
                A gamified marketplace where you collect items to level up and build a thriving community. Reach 1,000 members to retire!
              </Text>
            </View>
          </View>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

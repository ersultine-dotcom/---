import { ScrollView, Text, View, FlatList, Pressable, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useGame } from "@/lib/game-context";
import { MARKETPLACE_ITEMS, getRarityColor } from "@/lib/items";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";

export default function HomeScreen() {
  const { state, collectItem } = useGame();
  const router = useRouter();

  const handleCollectItem = (itemId: string) => {
    const item = MARKETPLACE_ITEMS.find((i) => i.id === itemId);
    if (item) {
      collectItem(item);
      Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    }
  };

  const currentLevelXp = state.level === 1 ? 0 : Math.pow(1.1, state.level - 1) * 100;
  const progressPercent = Math.min(100, ((state.totalXp - currentLevelXp) / (state.xpToNextLevel || 1)) * 100);

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Hero Section */}
        <View className="bg-primary px-6 py-8 gap-4">
          <View className="gap-1">
            <Text className="text-4xl font-bold text-background">Biron</Text>
            <Text className="text-sm text-background opacity-80">Marketplace of Power</Text>
          </View>

          {/* User Stats Card */}
          <View className="bg-background bg-opacity-10 rounded-lg p-4 gap-3">
            <View className="flex-row justify-between items-center">
              <View>
                <Text className="text-xs text-background opacity-70">Level</Text>
                <Text className="text-3xl font-bold text-background">{state.level}</Text>
              </View>
              <View className="flex-1 ml-4">
                <View className="flex-row justify-between mb-1">
                  <Text className="text-xs text-background opacity-70">XP Progress</Text>
                  <Text className="text-xs text-background opacity-70">{Math.floor(progressPercent)}%</Text>
                </View>
                <View className="h-2 bg-background bg-opacity-20 rounded-full overflow-hidden">
                  <View
                    className="h-full bg-background rounded-full"
                    style={{ width: `${progressPercent}%` }}
                  />
                </View>
              </View>
            </View>
            <Text className="text-xs text-background opacity-70">
              Items Collected: {state.inventory.length}
            </Text>
          </View>
        </View>

        {/* Marketplace Grid */}
        <View className="px-4 py-6 gap-4">
          <Text className="text-2xl font-bold text-foreground">Marketplace</Text>
          <FlatList
            data={MARKETPLACE_ITEMS}
            numColumns={2}
            columnWrapperStyle={{ gap: 12 }}
            scrollEnabled={false}
            renderItem={({ item }) => (
              <Pressable
                onPress={() => handleCollectItem(item.id)}
                style={({ pressed }) => [
                  { flex: 0.5 },
                  pressed && { opacity: 0.7 },
                ]}
              >
                <View className="bg-surface rounded-lg p-4 gap-2 border border-border">
                  <Text className="text-4xl text-center">{item.icon}</Text>
                  <Text className="text-sm font-semibold text-foreground text-center">{item.name}</Text>
                  <View className="flex-row justify-between items-center">
                    <Text
                      className="text-xs font-medium px-2 py-1 rounded"
                      style={{
                        color: getRarityColor(item.rarity),
                        backgroundColor: getRarityColor(item.rarity) + "20",
                      }}
                    >
                      {item.rarity}
                    </Text>
                    <Text className="text-xs font-bold text-success">+{item.xp} XP</Text>
                  </View>
                  <Pressable
                    onPress={() => handleCollectItem(item.id)}
                    className="bg-primary rounded py-2 mt-2"
                  >
                    <Text className="text-xs font-bold text-background text-center">Collect</Text>
                  </Pressable>
                </View>
              </Pressable>
            )}
            keyExtractor={(item) => item.id}
            contentContainerStyle={{ gap: 12 }}
          />
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

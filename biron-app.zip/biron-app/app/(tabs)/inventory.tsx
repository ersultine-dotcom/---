import { ScrollView, Text, View, FlatList, Pressable, Alert } from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useGame } from "@/lib/game-context";
import { getRarityColor } from "@/lib/items";
import * as Haptics from "expo-haptics";

export default function InventoryScreen() {
  const { state } = useGame();

  const sortedInventory = [...state.inventory].sort((a, b) => b.collectedAt - a.collectedAt);

  const totalXpFromItems = sortedInventory.reduce((sum, item) => sum + item.xp, 0);

  return (
    <ScreenContainer className="p-0">
      <ScrollView contentContainerStyle={{ flexGrow: 1 }}>
        {/* Header */}
        <View className="bg-primary px-6 py-8 gap-4">
          <Text className="text-2xl font-bold text-background">Inventory</Text>

          {/* Stats Grid */}
          <View className="flex-row gap-3">
            <View className="flex-1 bg-background bg-opacity-10 rounded-lg p-4 gap-1">
              <Text className="text-xs text-background opacity-70">Level</Text>
              <Text className="text-3xl font-bold text-background">{state.level}</Text>
            </View>
            <View className="flex-1 bg-background bg-opacity-10 rounded-lg p-4 gap-1">
              <Text className="text-xs text-background opacity-70">Total XP</Text>
              <Text className="text-2xl font-bold text-background">{state.totalXp}</Text>
            </View>
            <View className="flex-1 bg-background bg-opacity-10 rounded-lg p-4 gap-1">
              <Text className="text-xs text-background opacity-70">Items</Text>
              <Text className="text-2xl font-bold text-background">{state.inventory.length}</Text>
            </View>
          </View>
        </View>

        {/* Inventory List */}
        <View className="px-4 py-6 gap-4">
          {state.inventory.length === 0 ? (
            <View className="items-center justify-center py-12 gap-2">
              <Text className="text-4xl">📦</Text>
              <Text className="text-lg font-semibold text-foreground">Empty Inventory</Text>
              <Text className="text-sm text-muted text-center">
                Collect items from the marketplace to fill your inventory!
              </Text>
            </View>
          ) : (
            <FlatList
              data={sortedInventory}
              scrollEnabled={false}
              renderItem={({ item, index }) => (
                <View className="bg-surface rounded-lg p-4 border border-border flex-row items-center gap-4">
                  <Text className="text-3xl">{item.icon}</Text>
                  <View className="flex-1 gap-1">
                    <Text className="text-sm font-semibold text-foreground">{item.name}</Text>
                    <View className="flex-row items-center gap-2">
                      <Text
                        className="text-xs font-medium px-2 py-1 rounded"
                        style={{
                          color: getRarityColor(item.rarity),
                          backgroundColor: getRarityColor(item.rarity) + "20",
                        }}
                      >
                        {item.rarity}
                      </Text>
                      <Text className="text-xs text-success font-bold">+{item.xp} XP</Text>
                    </View>
                  </View>
                </View>
              )}
              keyExtractor={(item, index) => `${item.id}-${index}`}
              contentContainerStyle={{ gap: 8 }}
            />
          )}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

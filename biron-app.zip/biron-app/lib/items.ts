import { Item } from "./game-context";

export const MARKETPLACE_ITEMS: Item[] = [
  {
    id: "sword",
    name: "Iron Sword",
    xp: 50,
    rarity: "common",
    icon: "⚔️",
  },
  {
    id: "shield",
    name: "Wooden Shield",
    xp: 40,
    rarity: "common",
    icon: "🛡️",
  },
  {
    id: "potion",
    name: "Health Potion",
    xp: 30,
    rarity: "common",
    icon: "🧪",
  },
  {
    id: "gold_coin",
    name: "Gold Coin",
    xp: 25,
    rarity: "common",
    icon: "🪙",
  },
  {
    id: "book",
    name: "Spell Book",
    xp: 75,
    rarity: "uncommon",
    icon: "📖",
  },
  {
    id: "ring",
    name: "Silver Ring",
    xp: 60,
    rarity: "uncommon",
    icon: "💍",
  },
  {
    id: "amulet",
    name: "Mystical Amulet",
    xp: 100,
    rarity: "rare",
    icon: "✨",
  },
  {
    id: "crown",
    name: "Golden Crown",
    xp: 150,
    rarity: "epic",
    icon: "👑",
  },
  {
    id: "gem",
    name: "Ruby Gem",
    xp: 80,
    rarity: "uncommon",
    icon: "💎",
  },
  {
    id: "staff",
    name: "Wizard Staff",
    xp: 120,
    rarity: "rare",
    icon: "🪄",
  },
  {
    id: "boots",
    name: "Speed Boots",
    xp: 55,
    rarity: "uncommon",
    icon: "👢",
  },
  {
    id: "helmet",
    name: "Dragon Helmet",
    xp: 110,
    rarity: "rare",
    icon: "🐉",
  },
];

export function getItemById(id: string): Item | undefined {
  return MARKETPLACE_ITEMS.find((item) => item.id === id);
}

export function getRarityColor(rarity: string): string {
  switch (rarity) {
    case "common":
      return "#687076";
    case "uncommon":
      return "#22C55E";
    case "rare":
      return "#0a7ea4";
    case "epic":
      return "#F59E0B";
    default:
      return "#687076";
  }
}

import React, { createContext, useContext, useReducer, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";

export interface Item {
  id: string;
  name: string;
  xp: number;
  rarity: "common" | "uncommon" | "rare" | "epic";
  icon: string;
}

export interface CollectedItem extends Item {
  collectedAt: number;
}

export interface GameState {
  level: number;
  totalXp: number;
  xpToNextLevel: number;
  inventory: CollectedItem[];
  communityMembers: number;
}

type GameAction =
  | { type: "COLLECT_ITEM"; item: Item }
  | { type: "SET_STATE"; state: GameState }
  | { type: "INCREMENT_COMMUNITY" }
  | { type: "RESET_GAME" };

const initialState: GameState = {
  level: 1,
  totalXp: 0,
  xpToNextLevel: 100,
  inventory: [],
  communityMembers: 0,
};

function calculateLevel(totalXp: number): { level: number; xpToNextLevel: number } {
  let level = 1;
  let xpRequired = 100;
  let accumulatedXp = 0;

  while (accumulatedXp + xpRequired <= totalXp) {
    accumulatedXp += xpRequired;
    level += 1;
    xpRequired = Math.floor(xpRequired * 1.1);
  }

  return {
    level,
    xpToNextLevel: xpRequired - (totalXp - accumulatedXp),
  };
}

function gameReducer(state: GameState, action: GameAction): GameState {
  switch (action.type) {
    case "COLLECT_ITEM": {
      const newTotalXp = state.totalXp + action.item.xp;
      const { level, xpToNextLevel } = calculateLevel(newTotalXp);
      return {
        ...state,
        totalXp: newTotalXp,
        level,
        xpToNextLevel,
        inventory: [
          ...state.inventory,
          {
            ...action.item,
            collectedAt: Date.now(),
          },
        ],
      };
    }
    case "SET_STATE":
      return action.state;
    case "INCREMENT_COMMUNITY":
      return {
        ...state,
        communityMembers: state.communityMembers + 1,
      };
    case "RESET_GAME":
      return initialState;
    default:
      return state;
  }
}

interface GameContextType {
  state: GameState;
  collectItem: (item: Item) => void;
  incrementCommunity: () => void;
  resetGame: () => void;
}

const GameContext = createContext<GameContextType | undefined>(undefined);

export function GameProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(gameReducer, initialState);

  // Load state from AsyncStorage on mount
  useEffect(() => {
    const loadState = async () => {
      try {
        const savedState = await AsyncStorage.getItem("biron_game_state");
        if (savedState) {
          dispatch({ type: "SET_STATE", state: JSON.parse(savedState) });
        }
      } catch (error) {
        console.error("Failed to load game state:", error);
      }
    };
    loadState();
  }, []);

  // Save state to AsyncStorage whenever it changes
  useEffect(() => {
    const saveState = async () => {
      try {
        await AsyncStorage.setItem("biron_game_state", JSON.stringify(state));
      } catch (error) {
        console.error("Failed to save game state:", error);
      }
    };
    saveState();
  }, [state]);

  const collectItem = (item: Item) => {
    dispatch({ type: "COLLECT_ITEM", item });
  };

  const incrementCommunity = () => {
    dispatch({ type: "INCREMENT_COMMUNITY" });
  };

  const resetGame = () => {
    dispatch({ type: "RESET_GAME" });
  };

  return (
    <GameContext.Provider value={{ state, collectItem, incrementCommunity, resetGame }}>
      {children}
    </GameContext.Provider>
  );
}

export function useGame() {
  const context = useContext(GameContext);
  if (context === undefined) {
    throw new Error("useGame must be used within a GameProvider");
  }
  return context;
}

# Biron Marketplace - Mobile App Design

## Overview
Biron is a gamified marketplace where users browse and collect items to level up their character. The app tracks user progression and displays a retirement goal based on total community members.

---

## Screen List

1. **Home Screen** - Main marketplace view with item grid
2. **Item Detail Screen** - Item information and collection action
3. **Inventory Screen** - User's collected items and stats
4. **Leaderboard Screen** - Community progress toward retirement goal
5. **Settings Screen** - App preferences and info

---

## Primary Content and Functionality

### Home Screen
- **Hero Section**: Welcome message + current user level/XP
- **Marketplace Grid**: 2-column grid of collectible items with:
  - Item icon/image
  - Item name
  - XP reward value
  - "Collect" button
- **Bottom Navigation**: Quick access to Inventory, Leaderboard, Settings

### Item Detail Screen
- **Item Image**: Large display of item
- **Item Stats**: Name, description, XP value, rarity
- **Collect Button**: Primary action to add to inventory
- **Back Navigation**: Return to marketplace

### Inventory Screen
- **User Stats Card**: 
  - Current level
  - Total XP progress bar
  - Items collected count
- **Collected Items List**: Scrollable list of items with:
  - Item thumbnail
  - Collection date
  - XP value
  - Delete/remove option

### Leaderboard Screen
- **Retirement Goal Card**:
  - Target: 1,000 community members
  - Current count with progress bar
  - Percentage to goal
- **Milestone Messages**: 
  - At 50%: "Halfway there!"
  - At 100%: "🎉 Goal reached! Time to retire!"
- **Community Stats**: Total items collected, average level

### Settings Screen
- **App Info**: Version, about Biron
- **Theme Toggle**: Light/Dark mode
- **Reset Data**: Clear all progress (with confirmation)
- **About**: Developer info

---

## Key User Flows

### Main Collection Flow
1. User opens app → Home Screen displays marketplace
2. User browses items in grid
3. User taps item → Item Detail Screen
4. User taps "Collect" → Item added to inventory, XP awarded
5. User returns to Home → Sees updated stats
6. User taps Inventory → Views all collected items

### Retirement Tracking Flow
1. User taps Leaderboard tab
2. Views current community member count
3. Sees progress bar toward 1,000 members
4. At 100%, sees celebration message and retirement prompt

---

## Color Choices

| Element | Color | Usage |
|---------|-------|-------|
| **Primary** | #0a7ea4 (Teal) | Buttons, highlights, active states |
| **Background** | #ffffff (Light) / #151718 (Dark) | Screen backgrounds |
| **Surface** | #f5f5f5 (Light) / #1e2022 (Dark) | Cards, item containers |
| **Foreground** | #11181C (Light) / #ECEDEE (Dark) | Primary text |
| **Muted** | #687076 (Light) / #9BA1A6 (Dark) | Secondary text, descriptions |
| **Success** | #22C55E (Green) | XP gains, positive feedback |
| **Warning** | #F59E0B (Amber) | Rare items, caution states |
| **Error** | #EF4444 (Red) | Delete actions, errors |

---

## Layout Principles

- **Portrait Orientation**: All screens optimized for 9:16 aspect ratio
- **One-Handed Usage**: Primary actions (buttons, tabs) positioned in lower half
- **Safe Area**: Content respects notch and home indicator
- **Spacing**: 16px base unit for consistent padding/margins
- **Typography**: 
  - Headings: 24-32px, bold
  - Body: 16px, regular
  - Labels: 14px, medium
